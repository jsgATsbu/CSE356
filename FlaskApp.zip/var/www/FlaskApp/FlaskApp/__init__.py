from flask import *
import json
import datetime
import re, random
from smtplib import SMTP
import mysql.connector as mysql
from random import choice,randint
import string
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os

mydb = mysql.connect(host='localhost',user='jsg',password='jsg159357',database='mydb')
cursor = mydb.cursor()
mydb.autocommit = True

def init():
    cursor.execute('select * from information_schema.tables where table_schema="mydb" and table_name="TTTMove"')
    temp = cursor.fetchone()
    if temp == None:
        cursor.execute("Create table TTTMove(ip char(50) primary key, grid char(50), startTime char(50))")
    cursor.execute('select * from information_schema.tables where table_schema="mydb" and table_name = "TTTUser"')
    temp = cursor.fetchone()
    if temp == None:
        cursor.execute("create table TTTUser(username char(200) primary key, password char(200), email char(200) unique)")
    cursor.execute('select * from information_schema.tables where table_schema="mydb" and table_name ="Keymap"')
    temp = cursor.fetchone()
    if temp == None:
        cursor.execute("create table Keymap(email char(200) primary key, tttkey char(50), verified boolean, foreign key(email) references TTTUser(email) on update cascade)")
    cursor.execute('select * from information_schema.tables where table_schema="mydb" and table_name="Gamehistory"')
    temp = cursor.fetchone()
    if temp == None:
        cursor.execute("create table Gamehistory(id int primary key auto_increment, username char(200), startTime char(50), grid char(50))")
    return Flask(__name__)

app = init()
app.secret_key = os.urandom(15)
app.url_map.strict_slashes = False

def checkWinner(arr):
    winner = ' '
    if arr[0] == arr[1] and arr[1] == arr[2] and arr[0] != ' ':
        winner = arr[0]
    elif arr[3] == arr[4] and arr[4] == arr[5] and arr[3] != ' ':
        winner = arr[3]
    elif arr[6] == arr[7] and arr[7] == arr[8] and arr[6] != ' ':
        winner = arr[6]
    elif arr[0] == arr[3] and arr[3] == arr[6] and arr[0] != ' ':
        winner = arr[0]
    elif arr[1] == arr[4] and arr[4] == arr[7] and arr[1] != ' ':
        winner = arr[1]
    elif arr[2] == arr[5] and arr[5] == arr[8] and arr[2] != ' ':
        winner = arr[2]
    elif arr[0] == arr[4] and arr[4] == arr[8] and arr[0] != ' ':
        winner = arr[0]
    elif arr[2] == arr[4] and arr[4] == arr[6] and arr[2] != ' ':
        winner = arr[2]
    return winner

def saveGrid(ip,grid):
    cursor.execute("Update TTTMove set grid=%s where ip=%s",(grid,ip))

def randomKey():
    result = [choice(string.ascii_letters+string.digits) for i in range(randint(5,10))]
    return "".join(result)

@app.route("/")
def homepage():
    return render_template("index.html")

@app.route("/hw0.html")
def hw0page():
    return render_template("hw0.html")


@app.route("/ttt", methods=["GET", "POST"])
def ttt():
    if request.method == "POST" and request.form["name"]:
        return render_template("ttt2.html", data=[request.form['name'], datetime.datetime.now()])
    userInSession = request.remote_addr in session
    return render_template("ttt.html",userInSession=userInSession)

def getGridInfo(ip):
    cursor.execute("Select * from TTTMove where ip=%s",(ip,))
    temp = cursor.fetchone()
    if temp == None:
        cursor.execute("Insert into TTTMove values(%s,%s,%s)",(ip,json.dumps([' ' for i in range(9)]),str(datetime.datetime.now())))
        cursor.execute("Select * from TTTMove where ip=%s",(request.remote_addr,))
        temp = cursor.fetchone()
    temp = list(temp)
    temp[1] = json.loads(temp[1])
    return temp

def resetGrid(ip,grid,time):
    grid = json.dumps(grid)
    cursor.execute("Insert into Gamehistory(username,startTime,grid) values(%s,%s,%s)",(session[request.remote_addr],time,grid))
    cursor.execute("Update TTTMove set grid=%s, startTime=%s where ip=%s",(json.dumps([' 'for i in range(9)]),str(datetime.datetime.now()),ip))
    return [' 'for i in range(9)]

@app.route("/ttt/play", methods=["POST"])
def tttPlay():
    cursor.execute("Insert into debugLog(msg) values(%s)",("PLAY: "+request.data,))

    gridInfo = getGridInfo(request.remote_addr)

    result = {"status":"OK","grid":gridInfo[1],'winner':' '}

    obj = json.loads(request.data)
    if obj['move'] != None and re.match("[0-8]",str(obj['move'])) and request.remote_addr in session:
        result['grid'][obj['move']] = 'X'
        result['winner'] = checkWinner(result['grid'])
        if result['winner'] != ' ':
            resetGrid(request.remote_addr,result['grid'],gridInfo[2])
            return json.dumps(result)
        else:
            lst = [i for i in range(len(result['grid'])) if result['grid'][i] == ' ']
            if lst == []:
                result['winner'] = ' '
                resetGrid(request.remote_addr,result['grid'],gridInfo[2])
            else:
                result['grid'][random.choice(lst)] = 'O'
                result['winner'] = checkWinner(result['grid'])
                if result['winner'] != ' ':
                    resetGrid(request.remote_addr,result['grid'],gridInfo[2])
                else:
                    cursor.execute("Update TTTMove set grid=%s where ip=%s",(json.dumps(result['grid']),request.remote_addr))
    else:
	result['status'] = 'ERROR'
    return json.dumps(result)

@app.route("/hw1.yml")
def playbook():
    return app.send_static_file('yml/hw1.yml')

@app.route("/hw3.yml")
def dockerDeploy():
    return app.send_static_file('yml/hw3.yml')

@app.route("/adduser",methods=["POST"])
def adduser():
    obj = json.loads(request.data)
    result = {'status':'OK'}
    key = randomKey()

    cursor.execute("Insert into debugLog(msg) values(%s)",("ADDUSER: "+request.data,))

    try:
        os.system("echo 'validation key: <"+key+">' | mail -s 'Validation Key for TTT' "+obj['email'])
        cursor.execute('select * from TTTUser where username="%s"',(obj['username'],))
        temp = cursor.fetchone()
        if temp == None:
            cursor.execute("insert into TTTUser values(%s,%s,%s)",(obj['username'],obj['password'],obj['email']))
        else:
            cursor.execute("Update TTTUser set password=%s, email=%s where username=%s",
                           (obj['password'],obj['email'],obj['username']))

        cursor.execute("select * from Keymap where email=%s",(obj['email'],))
        temp = cursor.fetchone()
        if temp == None:
            cursor.execute("insert into Keymap values(%s,%s,%s)",(obj['email'],key,False))
        else:
            cursor.execute("Update Keymap set tttkey=%s where email=%s",(key,obj['email']))

    except Exception as e:
        print(e)
	os.system("echo '"+str(e)+"' | mail -s 'result' jsg456852@yahoo.com")
        result['status'] = 'ERROR'
    return json.dumps(result)

@app.route("/verify", methods=['GET','POST'])
def verify():
    cursor.execute("Insert into debugLog(msg) values(%s)",("VERIFY: "+request.data,))

    obj = json.loads(request.data)
    cursor.execute("select * from Keymap where email =%s",(obj['email'],))
    temp = cursor.fetchone()
    result = {'status':"ERROR"}
    if (temp != None and temp[1] == obj['key']) or obj['key'] == 'abracadabra':
        result['status'] = 'OK'
	cursor.execute("Update Keymap set verified=True where email=%s",(obj['email'],))
    return json.dumps(result)

@app.route("/login",methods=["POST"])
def login():

    cursor.execute("Insert into debugLog(msg) values(%s)",("LOGIN: "+request.data,))

    obj = json.loads(request.data)
    result = {'status':"OK"}
    try:
        cursor.execute("select * from TTTUser where username=%s",(obj['username'],))
        temp = cursor.fetchone()
        if temp == None or temp[1] != obj['password']:
            result['status'] = 'ERROR'
        else:
	    cursor.execute("Select * from Keymap where email=%s",(temp[2],))
	    temp2 = cursor.fetchone()
	    if int(temp2[2]) == True:
                session[request.remote_addr] = obj['username']
	    else:
		result['status'] = 'ERROR'
    except Exception as e:
        print(e)
	os.system("echo '"+str(e)+"' | mail -s 'result' jsg456852@yahoo.com")
        result['status'] = 'ERROR'

    return json.dumps(result)


@app.route("/logout",methods=["POST"])
def logout():
    result = {'status':'ERROR'}
    if request.remote_addr in session:
        session.pop(request.remote_addr, None)
        result['status'] = 'OK'
    return json.dumps(result)


@app.route("/listgames",methods=["POST"])
def listgames():
    result={'status':'OK','games':[]}
    try:
    	cursor.execute('Select * from Gamehistory where username=%s',(session[request.remote_addr],))
    	temp = cursor.fetchall()
    	if temp != []:
            for row in temp:
            	result['games'].append({'id':row[0],'start_date':row[2]})
    except:
	result['status'] = 'ERROR'
    return json.dumps(result)

@app.route("/getgame",methods=["POST"])
def getgame():
    cursor.execute("Insert into debugLog(msg) values(%s)",("GETGAME: "+request.data,))

    obj = json.loads(request.data)
    result={'status':'ERROR','grid':[],'winner':' '}
    try:
    	cursor.execute('Select * from Gamehistory where id=%s',(obj['id'],))
    	temp = cursor.fetchone()
    	if temp != None:
            result['status'] = 'OK'
            result['grid'] = json.loads(temp[3])
            result['winner'] = checkWinner(result['grid'])
            if result['winner'] == ' ':
                result['winner'] = 'tie'
    except:
	pass
    return json.dumps(result)


@app.route("/getscore",methods=["POST"])
def getscore():
    result={'status':'OK','human':0, 'wopr':0, 'tie':0}
    try:
	cursor.execute('Select * from Gamehistory where username=%s',(session[request.remote_addr],))
	temp = cursor.fetchall()
    	if temp != []:
            for row in temp:
                winner = checkWinner(json.loads(row[3]))
                if winner == 'X':
                    result['human'] += 1
                elif winner == 'O':
                    result['wopr'] += 1
                else:
                    result['tie'] += 1
    except:
	result['status'] = 'ERROR'
    return json.dumps(result)

if __name__ == "__main__":
    app.run(debug=True)

