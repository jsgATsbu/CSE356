import os

os.system("echo 'hello' | mail -s 'HAHA' jsg456852@yahoo.com")
