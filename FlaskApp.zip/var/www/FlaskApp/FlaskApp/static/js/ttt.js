var register = function(){
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url:"/adduser",
        data: JSON.stringify({
            username: document.getElementById("Rusername").value,
            password: document.getElementById("Rpassword").value,
            email: document.getElementById("Remail").value,
        }),
        success: function(data){
            console.log(data);
        },
        error: function (msg) {
            alert("error" + msg);
        }
    });
}.bind(this);

var verify = function(){
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url:"/verify",
        data: JSON.stringify({
            email: document.getElementById("email").value,
            key: document.getElementById("key").value
        }),
        success: function(data){
            console.log(data);
        },
        error: function (msg) {
            alert("error" + msg);
        }
    });
}.bind(this);

var login = function(){
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/login",
        data: JSON.stringify({
            username: document.getElementById("Lusername").value,
            password: document.getElementById("Lpassword").value,
        }),
        success: function(data){
            location.reload();
        },
        error: function (msg) {
            alert("error" + msg);
        }
    })
}.bind(this);

var logout = function(){
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/logout",
        data: JSON.stringify({
        }),
        success: function(data){
            location.reload();
        },
        error: function (msg) {
            alert("error" + msg);
        }
    })
}.bind(this);


