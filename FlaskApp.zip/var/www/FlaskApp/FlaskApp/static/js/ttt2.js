var grids = document.getElementById("ttt");

var update = function(data){
    for(let i=0;i<data.grid.length;i++){
        grids.rows[Math.floor(i/3)].cells[i%3].innerHTML=data.grid[i];
    }
}.bind(this);

var btnClick = function(i){
    return function(){
        $.ajax({
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({
                move: i,
            }),
            dataType: "json",
            url: "/ttt/play",
            success: function(data){
                update(data);
            },
            error: function(msg){
                alert("Update Error");
            }
        });}
}.bind(this);


for(var i=0; i<9; i++){
    grids.rows[Math.floor(i/3)].cells[i%3].addEventListener("click", btnClick(i));
}

var listGames = function(){
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/listgames",
        data: JSON.stringify({
        }),
        success: function(data){
            console.log(data);
        },
        error: function (msg) {
            alert("error" + msg);
        }
    })
}.bind(this);

var getGame = function(){
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/getgame",
        data: JSON.stringify({
            id: document.getElementById("gameID").value,
        }),
        success: function(data){
            console.log(data);
        },
        error: function (msg) {
            alert("error" + msg);
        }
    })
}.bind(this);

var getScore = function(){
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/getscore",
        data: JSON.stringify({
        }),
        success: function(data){
            console.log(data);
        },
        error: function (msg) {
            alert("error" + msg);
        }
    })
}.bind(this);

